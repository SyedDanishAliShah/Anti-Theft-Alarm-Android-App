package com.example.antitheftalarmapp.dataclasses

data class CardData(val title: String, val description: String)
